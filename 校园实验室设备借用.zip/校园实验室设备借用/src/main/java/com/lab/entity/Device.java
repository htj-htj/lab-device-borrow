package com.lab.entity;

public class Device {
    private int id;
    private String deviceName;
    private String deviceCode;
    private String category;
    private String description;
    private int totalQuantity;
    private int availableQuantity;
    private int status;
    private String createTime;

    public Device() {}

    public Device(String deviceName, String deviceCode, String category, String description, int totalQuantity) {
        this.deviceName = deviceName;
        this.deviceCode = deviceCode;
        this.category = category;
        this.description = description;
        this.totalQuantity = totalQuantity;
        this.availableQuantity = totalQuantity;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDeviceName() { return deviceName; }
    public void setDeviceName(String deviceName) { this.deviceName = deviceName; }
    public String getDeviceCode() { return deviceCode; }
    public void setDeviceCode(String deviceCode) { this.deviceCode = deviceCode; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getTotalQuantity() { return totalQuantity; }
    public void setTotalQuantity(int totalQuantity) { this.totalQuantity = totalQuantity; }
    public int getAvailableQuantity() { return availableQuantity; }
    public void setAvailableQuantity(int availableQuantity) { this.availableQuantity = availableQuantity; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public String getCreateTime() { return createTime; }
    public void setCreateTime(String createTime) { this.createTime = createTime; }
}
