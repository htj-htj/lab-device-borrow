package com.lab.entity;

public class BorrowRecord {
    private int id;
    private int userId;
    private int deviceId;
    private int borrowQuantity;
    private String borrowTime;
    private String expectedReturnTime;
    private String actualReturnTime;
    private String status;
    private String remark;
    private String createTime;

    private String userName;
    private String realName;
    private String deviceName;
    private String deviceCode;

    public BorrowRecord() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getDeviceId() { return deviceId; }
    public void setDeviceId(int deviceId) { this.deviceId = deviceId; }
    public int getBorrowQuantity() { return borrowQuantity; }
    public void setBorrowQuantity(int borrowQuantity) { this.borrowQuantity = borrowQuantity; }
    public String getBorrowTime() { return borrowTime; }
    public void setBorrowTime(String borrowTime) { this.borrowTime = borrowTime; }
    public String getExpectedReturnTime() { return expectedReturnTime; }
    public void setExpectedReturnTime(String expectedReturnTime) { this.expectedReturnTime = expectedReturnTime; }
    public String getActualReturnTime() { return actualReturnTime; }
    public void setActualReturnTime(String actualReturnTime) { this.actualReturnTime = actualReturnTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
    public String getCreateTime() { return createTime; }
    public void setCreateTime(String createTime) { this.createTime = createTime; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getRealName() { return realName; }
    public void setRealName(String realName) { this.realName = realName; }
    public String getDeviceName() { return deviceName; }
    public void setDeviceName(String deviceName) { this.deviceName = deviceName; }
    public String getDeviceCode() { return deviceCode; }
    public void setDeviceCode(String deviceCode) { this.deviceCode = deviceCode; }
}
