package com.lab.servlet;

import com.lab.dao.DeviceDAO;
import com.lab.entity.Device;
import com.lab.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/device")
public class DeviceServlet extends HttpServlet {

    private DeviceDAO deviceDAO = new DeviceDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("list".equals(action)) {
            list(req, resp);
        } else if ("detail".equals(action)) {
            detail(req, resp);
        } else if ("categories".equals(action)) {
            categories(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("add".equals(action)) {
            add(req, resp);
        } else if ("update".equals(action)) {
            update(req, resp);
        } else if ("delete".equals(action)) {
            delete(req, resp);
        }
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String keyword = req.getParameter("keyword");
        String category = req.getParameter("category");
        List<Device> list = deviceDAO.listByCondition(keyword, category);
        writeJson(resp, okData(list));
    }

    private void detail(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Device d = deviceDAO.getById(id);
        if (d != null) {
            writeJson(resp, okData(d));
        } else {
            writeJson(resp, error("设备不存在"));
        }
    }

    private void categories(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        writeJson(resp, okData(deviceDAO.listCategories()));
    }

    private void add(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        Device d = new Device();
        d.setDeviceName(req.getParameter("deviceName"));
        d.setDeviceCode(req.getParameter("deviceCode"));
        d.setCategory(req.getParameter("category"));
        d.setDescription(req.getParameter("description"));
        d.setTotalQuantity(Integer.parseInt(req.getParameter("totalQuantity")));
        writeJson(resp, deviceDAO.add(d) ? ok("添加成功") : error("添加失败"));
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        Device d = new Device();
        d.setId(Integer.parseInt(req.getParameter("id")));
        d.setDeviceName(req.getParameter("deviceName"));
        d.setDeviceCode(req.getParameter("deviceCode"));
        d.setCategory(req.getParameter("category"));
        d.setDescription(req.getParameter("description"));
        d.setTotalQuantity(Integer.parseInt(req.getParameter("totalQuantity")));
        Device old = deviceDAO.getById(d.getId());
        if (old == null) {
            writeJson(resp, error("设备不存在"));
            return;
        }
        int borrowed = old.getTotalQuantity() - old.getAvailableQuantity();
        if (d.getTotalQuantity() < borrowed) {
            writeJson(resp, error("库存不能小于已借出数量(" + borrowed + ")"));
            return;
        }
        d.setAvailableQuantity(d.getTotalQuantity() - borrowed);
        boolean ok = deviceDAO.update(d);
        if (ok) {
            Device updated = deviceDAO.getById(d.getId());
            int diff = updated.getAvailableQuantity() - old.getAvailableQuantity();
            if (diff != 0) {
                deviceDAO.updateAvailableQuantity(d.getId(), diff);
            }
        }
        writeJson(resp, ok ? ok("更新成功") : error("更新失败"));
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        int id = Integer.parseInt(req.getParameter("id"));
        writeJson(resp, deviceDAO.delete(id) ? ok("删除成功") : error("删除失败：有设备正在使用中"));
    }

    private Map<String, Object> ok(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("msg", msg);
        return m;
    }

    private Map<String, Object> okData(Object data) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("data", data);
        return m;
    }

    private Map<String, Object> error(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 1);
        m.put("msg", msg);
        return m;
    }

    private void writeJson(HttpServletResponse resp, Object obj) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter pw = resp.getWriter();
        pw.print(com.alibaba.fastjson2.JSON.toJSONString(obj));
        pw.flush();
        pw.close();
    }
}
