package com.lab.servlet;

import com.lab.dao.UserDAO;
import com.lab.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/user")
public class UserServlet extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("login".equals(action)) {
            login(req, resp);
        } else if ("register".equals(action)) {
            register(req, resp);
        } else if ("logout".equals(action)) {
            logout(req, resp);
        } else if ("update".equals(action)) {
            update(req, resp);
        } else if ("delete".equals(action)) {
            deleteUser(req, resp);
        } else if ("list".equals(action)) {
            list(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("current".equals(action)) {
            currentUser(req, resp);
        } else if ("list".equals(action)) {
            list(req, resp);
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        User user = userDAO.login(username, password);
        Map<String, Object> result = new HashMap<>();
        if (user != null) {
            HttpSession session = req.getSession();
            session.setAttribute("loginUser", user);
            result.put("code", 0);
            result.put("msg", "登录成功");
            result.put("data", user);
        } else {
            result.put("code", 1);
            result.put("msg", "用户名或密码错误");
        }
        writeJson(resp, result);
    }

    private void register(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String realName = req.getParameter("realName");
        String studentNo = req.getParameter("studentNo");
        String phone = req.getParameter("phone");

        Map<String, Object> result = new HashMap<>();
        if (userDAO.existByUsername(username)) {
            result.put("code", 1);
            result.put("msg", "用户名已存在");
        } else {
            User user = new User(username, password, realName, studentNo, phone, "student");
            if (userDAO.register(user)) {
                result.put("code", 0);
                result.put("msg", "注册成功");
            } else {
                result.put("code", 1);
                result.put("msg", "注册失败");
            }
        }
        writeJson(resp, result);
    }

    private void logout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        session.invalidate();
        Map<String, Object> result = new HashMap<>();
        result.put("code", 0);
        result.put("msg", "已退出登录");
        writeJson(resp, result);
    }

    private void currentUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        Map<String, Object> result = new HashMap<>();
        if (session != null && session.getAttribute("loginUser") != null) {
            User user = (User) session.getAttribute("loginUser");
            result.put("code", 0);
            result.put("data", user);
        } else {
            result.put("code", 1);
            result.put("msg", "未登录");
        }
        writeJson(resp, result);
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("未登录"));
            return;
        }
        String realName = req.getParameter("realName");
        String phone = req.getParameter("phone");
        String password = req.getParameter("password");
        User u = new User();
        u.setId(loginUser.getId());
        u.setRealName(realName);
        u.setPhone(phone);
        u.setPassword(password != null && !password.isEmpty() ? password : loginUser.getPassword());
        boolean ok = userDAO.update(u);
        if (ok) {
            User updated = userDAO.getById(loginUser.getId());
            req.getSession().setAttribute("loginUser", updated);
            writeJson(resp, ok("修改成功"));
        } else {
            writeJson(resp, error("修改失败"));
        }
    }

    private void deleteUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        int id = Integer.parseInt(req.getParameter("id"));
        if (id == loginUser.getId()) {
            writeJson(resp, error("不能删除自己"));
            return;
        }
        boolean ok = userDAO.delete(id);
        writeJson(resp, ok ? ok("删除成功") : error("删除失败，不能删除管理员或存在借用记录的用户"));
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        writeJson(resp, okData(userDAO.listAll()));
    }

    private Map<String, Object> ok(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("msg", msg);
        return m;
    }

    private Map<String, Object> okData(Object data) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("data", data);
        return m;
    }

    private Map<String, Object> error(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 1);
        m.put("msg", msg);
        return m;
    }

    private void writeJson(HttpServletResponse resp, Object obj) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter pw = resp.getWriter();
        pw.print(com.alibaba.fastjson2.JSON.toJSONString(obj));
        pw.flush();
        pw.close();
    }
}
