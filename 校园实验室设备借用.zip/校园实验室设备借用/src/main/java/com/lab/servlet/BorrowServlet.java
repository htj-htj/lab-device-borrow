package com.lab.servlet;

import com.lab.dao.BorrowDAO;
import com.lab.dao.DeviceDAO;
import com.lab.entity.BorrowRecord;
import com.lab.entity.Device;
import com.lab.entity.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/borrow")
public class BorrowServlet extends HttpServlet {

    private BorrowDAO borrowDAO = new BorrowDAO();
    private DeviceDAO deviceDAO = new DeviceDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("list".equals(action)) {
            list(req, resp);
        } else if ("mine".equals(action)) {
            mine(req, resp);
        } else if ("overdue".equals(action)) {
            overdue(req, resp);
        } else if ("stats".equals(action)) {
            stats(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("borrow".equals(action)) {
            borrow(req, resp);
        } else if ("return".equals(action)) {
            returnDevice(req, resp);
        }
    }

    private void borrow(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("请先登录"));
            return;
        }
        int deviceId = Integer.parseInt(req.getParameter("deviceId"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));
        int days = Integer.parseInt(req.getParameter("days"));
        String remark = req.getParameter("remark");

        Device device = deviceDAO.getById(deviceId);
        if (device == null) {
            writeJson(resp, error("设备不存在"));
            return;
        }
        if (quantity <= 0 || quantity > device.getAvailableQuantity()) {
            writeJson(resp, error("库存不足，剩余：" + device.getAvailableQuantity()));
            return;
        }

        if (!deviceDAO.updateAvailableQuantity(deviceId, -quantity)) {
            writeJson(resp, error("借用失败，库存不足"));
            return;
        }
        boolean ok = borrowDAO.add(loginUser.getId(), deviceId, quantity, days, remark);
        if (!ok) {
            deviceDAO.updateAvailableQuantity(deviceId, quantity);
            writeJson(resp, error("借用失败，请稍后重试"));
            return;
        }
        writeJson(resp, ok("借用成功，请按时归还"));
    }

    private void returnDevice(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("请先登录"));
            return;
        }
        int recordId = Integer.parseInt(req.getParameter("recordId"));
        BorrowRecord record = borrowDAO.getById(recordId);
        if (record == null) {
            writeJson(resp, error("记录不存在"));
            return;
        }
        if (!"admin".equals(loginUser.getRole()) && record.getUserId() != loginUser.getId()) {
            writeJson(resp, error("无权限"));
            return;
        }
        if ("returned".equals(record.getStatus())) {
            writeJson(resp, error("已归还"));
            return;
        }

        boolean ok = borrowDAO.returnDevice(recordId);
        if (ok) {
            deviceDAO.updateAvailableQuantity(record.getDeviceId(), record.getBorrowQuantity());
            writeJson(resp, ok("归还成功"));
        } else {
            writeJson(resp, error("归还失败"));
        }
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            writeJson(resp, error("无权限"));
            return;
        }
        borrowDAO.updateOverdueStatus();
        String status = req.getParameter("status");
        List<BorrowRecord> list;
        if (status != null && !status.isEmpty()) {
            list = borrowDAO.listByStatus(status);
        } else {
            list = borrowDAO.listAll();
        }
        writeJson(resp, okData(list));
    }

    private void mine(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("未登录"));
            return;
        }
        borrowDAO.updateOverdueStatus();
        writeJson(resp, okData(borrowDAO.listByUserId(loginUser.getId())));
    }

    private void overdue(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("未登录"));
            return;
        }
        borrowDAO.updateOverdueStatus();
        writeJson(resp, okData(borrowDAO.listOverdue()));
    }

    private void stats(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User loginUser = (User) req.getSession().getAttribute("loginUser");
        if (loginUser == null) {
            writeJson(resp, error("未登录"));
            return;
        }
        borrowDAO.updateOverdueStatus();
        Map<String, Object> data = new HashMap<>();
        if ("admin".equals(loginUser.getRole())) {
            data.put("totalBorrowed", borrowDAO.listByStatus("borrowed").size() + borrowDAO.listByStatus("overdue").size());
            data.put("overdueCount", borrowDAO.countOverdue());
            data.put("totalDevices", deviceDAO.listAll().size());
            data.put("totalUsers", new com.lab.dao.UserDAO().listAll().size());
        } else {
            data.put("borrowedCount", borrowDAO.countByUserIdAndStatus(loginUser.getId(), "borrowed"));
            data.put("overdueCount", borrowDAO.countByUserIdAndStatus(loginUser.getId(), "overdue"));
            data.put("returnedCount", borrowDAO.countByUserIdAndStatus(loginUser.getId(), "returned"));
        }
        writeJson(resp, okData(data));
    }

    private Map<String, Object> ok(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("msg", msg);
        return m;
    }

    private Map<String, Object> okData(Object data) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 0);
        m.put("data", data);
        return m;
    }

    private Map<String, Object> error(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("code", 1);
        m.put("msg", msg);
        return m;
    }

    private void writeJson(HttpServletResponse resp, Object obj) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter pw = resp.getWriter();
        pw.print(com.alibaba.fastjson2.JSON.toJSONString(obj));
        pw.flush();
        pw.close();
    }
}
