package com.lab.dao;

import com.lab.entity.Device;
import com.lab.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DeviceDAO {

    public List<Device> listAll() {
        return listByCondition(null, null);
    }

    public List<Device> listByCondition(String keyword, String category) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Device> list = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            StringBuilder sql = new StringBuilder("SELECT * FROM devices WHERE 1=1");
            List<Object> params = new ArrayList<>();
            if (keyword != null && !keyword.trim().isEmpty()) {
                sql.append(" AND (device_name LIKE ? OR device_code LIKE ?)");
                params.add("%" + keyword.trim() + "%");
                params.add("%" + keyword.trim() + "%");
            }
            if (category != null && !category.trim().isEmpty()) {
                sql.append(" AND category=?");
                params.add(category.trim());
            }
            sql.append(" ORDER BY id DESC");
            ps = conn.prepareStatement(sql.toString());
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(getDeviceFromRS(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return list;
    }

    public Device getById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement("SELECT * FROM devices WHERE id=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return getDeviceFromRS(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return null;
    }

    public boolean add(Device device) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement("INSERT INTO devices (device_name, device_code, category, description, total_quantity, available_quantity) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, device.getDeviceName());
            ps.setString(2, device.getDeviceCode());
            ps.setString(3, device.getCategory());
            ps.setString(4, device.getDescription());
            ps.setInt(5, device.getTotalQuantity());
            ps.setInt(6, device.getTotalQuantity());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public boolean update(Device device) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement("UPDATE devices SET device_name=?, device_code=?, category=?, description=?, total_quantity=? WHERE id=?");
            ps.setString(1, device.getDeviceName());
            ps.setString(2, device.getDeviceCode());
            ps.setString(3, device.getCategory());
            ps.setString(4, device.getDescription());
            ps.setInt(5, device.getTotalQuantity());
            ps.setInt(6, device.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public boolean delete(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement("DELETE FROM devices WHERE id=? AND available_quantity = total_quantity");
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public boolean updateAvailableQuantity(int id, int quantity) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement("UPDATE devices SET available_quantity = available_quantity + ? WHERE id=? AND available_quantity + ? >= 0 AND available_quantity + ? <= total_quantity");
            ps.setInt(1, quantity);
            ps.setInt(2, id);
            ps.setInt(3, quantity);
            ps.setInt(4, quantity);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public List<String> listCategories() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<String> list = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT DISTINCT category FROM devices WHERE category IS NOT NULL AND category != ''");
            while (rs.next()) {
                list.add(rs.getString("category"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, stmt, rs);
        }
        return list;
    }

    private Device getDeviceFromRS(ResultSet rs) throws SQLException {
        Device d = new Device();
        d.setId(rs.getInt("id"));
        d.setDeviceName(rs.getString("device_name"));
        d.setDeviceCode(rs.getString("device_code"));
        d.setCategory(rs.getString("category"));
        d.setDescription(rs.getString("description"));
        d.setTotalQuantity(rs.getInt("total_quantity"));
        d.setAvailableQuantity(rs.getInt("available_quantity"));
        d.setStatus(rs.getInt("status"));
        Timestamp ts = rs.getTimestamp("create_time");
        d.setCreateTime(ts != null ? ts.toString() : null);
        return d;
    }
}
