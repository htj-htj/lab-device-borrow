package com.lab.dao;

import com.lab.entity.BorrowRecord;
import com.lab.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BorrowDAO {

    public boolean add(int userId, int deviceId, int borrowQuantity, int days, String remark) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "INSERT INTO borrow_records (user_id, device_id, borrow_quantity, expected_return_time, remark) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY), ?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, deviceId);
            ps.setInt(3, borrowQuantity);
            ps.setInt(4, days);
            ps.setString(5, remark);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public List<BorrowRecord> listAll() {
        return listByCondition(null, null, null);
    }

    public List<BorrowRecord> listByUserId(int userId) {
        return listByCondition(userId, null, null);
    }

    public List<BorrowRecord> listByStatus(String status) {
        return listByCondition(null, null, status);
    }

    public List<BorrowRecord> listOverdue() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BorrowRecord> list = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT r.*, u.username, u.real_name, d.device_name, d.device_code " +
                    "FROM borrow_records r LEFT JOIN users u ON r.user_id = u.id " +
                    "LEFT JOIN devices d ON r.device_id = d.id " +
                    "WHERE r.status = 'borrowed' AND r.expected_return_time < NOW() " +
                    "ORDER BY r.expected_return_time ASC";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(getRecordFromRS(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return list;
    }

    public boolean returnDevice(int recordId) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "UPDATE borrow_records SET status='returned', actual_return_time=NOW() WHERE id=? AND status IN ('borrowed','overdue')";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, recordId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps);
        }
        return false;
    }

    public boolean updateOverdueStatus() {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = DBUtil.getConnection();
            stmt = conn.createStatement();
            int n1 = stmt.executeUpdate("UPDATE borrow_records SET status='overdue' WHERE status='borrowed' AND expected_return_time < NOW()");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, stmt);
        }
        return false;
    }

    public BorrowRecord getById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT r.*, u.username, u.real_name, d.device_name, d.device_code " +
                    "FROM borrow_records r LEFT JOIN users u ON r.user_id = u.id " +
                    "LEFT JOIN devices d ON r.device_id = d.id WHERE r.id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return getRecordFromRS(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return null;
    }

    public int countByUserIdAndStatus(int userId, String status) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM borrow_records WHERE user_id=? AND status=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setString(2, status);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return 0;
    }

    public int countOverdue() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT COUNT(*) FROM borrow_records WHERE status='overdue'");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, stmt, rs);
        }
        return 0;
    }

    private List<BorrowRecord> listByCondition(Integer userId, Integer deviceId, String status) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<BorrowRecord> list = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            StringBuilder sql = new StringBuilder(
                    "SELECT r.*, u.username, u.real_name, d.device_name, d.device_code " +
                    "FROM borrow_records r LEFT JOIN users u ON r.user_id = u.id " +
                    "LEFT JOIN devices d ON r.device_id = d.id WHERE 1=1");
            List<Object> params = new ArrayList<>();
            if (userId != null) {
                sql.append(" AND r.user_id=?");
                params.add(userId);
            }
            if (deviceId != null) {
                sql.append(" AND r.device_id=?");
                params.add(deviceId);
            }
            if (status != null && !status.trim().isEmpty()) {
                sql.append(" AND r.status=?");
                params.add(status.trim());
            }
            sql.append(" ORDER BY r.id DESC");
            ps = conn.prepareStatement(sql.toString());
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(getRecordFromRS(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }
        return list;
    }

    private BorrowRecord getRecordFromRS(ResultSet rs) throws SQLException {
        BorrowRecord r = new BorrowRecord();
        r.setId(rs.getInt("id"));
        r.setUserId(rs.getInt("user_id"));
        r.setDeviceId(rs.getInt("device_id"));
        r.setBorrowQuantity(rs.getInt("borrow_quantity"));
        r.setBorrowTime(rs.getString("borrow_time"));
        r.setExpectedReturnTime(rs.getString("expected_return_time"));
        r.setActualReturnTime(rs.getString("actual_return_time"));
        r.setStatus(rs.getString("status"));
        r.setRemark(rs.getString("remark"));
        r.setCreateTime(rs.getString("create_time"));
        r.setUserName(rs.getString("username"));
        r.setRealName(rs.getString("real_name"));
        r.setDeviceName(rs.getString("device_name"));
        r.setDeviceCode(rs.getString("device_code"));
        return r;
    }
}
