const API = {
    user: ctx => `${ctx}/api/user`,
    device: ctx => `${ctx}/api/device`,
    borrow: ctx => `${ctx}/api/borrow`
};

let CTX = '';

async function api(url, params = {}, method = 'GET') {
    const qs = Object.keys(params)
        .filter(k => params[k] !== undefined && params[k] !== null && params[k] !== '')
        .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`)
        .join('&');
    const full = method === 'GET' ? `${url}${qs ? '?' + qs : ''}` : url;
    const opts = {
        method,
        headers: method === 'POST' ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}
    };
    if (method === 'POST') {
        opts.body = qs;
    }
    const res = await fetch(full, opts);
    return res.json();
}

function toast(msg, type = 'info') {
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2500);
}

function getCurrentUser() {
    return JSON.parse(sessionStorage.getItem('loginUser') || 'null');
}

function setCurrentUser(u) {
    if (u) sessionStorage.setItem('loginUser', JSON.stringify(u));
    else sessionStorage.removeItem('loginUser');
}

function formatTime(t) {
    if (!t) return '-';
    return t.replace('T', ' ').substring(0, 19);
}

function daysLeft(expected) {
    if (!expected) return 0;
    const exp = new Date(expected.replace(' ', 'T'));
    const now = new Date();
    const diff = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
    return diff;
}

function statusTag(status) {
    const map = { borrowed: ['借用中', 'borrowed'], returned: ['已归还', 'returned'], overdue: ['已逾期', 'overdue'] };
    const [text, cls] = map[status] || [status, ''];
    return `<span class="tag tag-${cls}">${text}</span>`;
}

function showModal(content, onConfirm) {
    const mask = document.createElement('div');
    mask.className = 'modal-mask';
    mask.innerHTML = `<div class="modal">${content}<div class="modal-actions"><button class="btn btn-default" id="m-cancel">取消</button><button class="btn btn-primary" id="m-ok">确定</button></div></div>`;
    document.body.appendChild(mask);
    mask.querySelector('#m-cancel').onclick = () => mask.remove();
    mask.querySelector('#m-ok').onclick = () => {
        const data = onConfirm && onConfirm(mask);
        if (data !== false) mask.remove();
    };
    return mask;
}

async function initCtx() {
    try {
        const r = await fetch(window.location.pathname).catch(() => null);
    } catch(e) {}
    const p = window.location.pathname;
    const idx = p.indexOf('/api/');
    CTX = idx > 0 ? p.substring(0, idx) : p.length > 1 ? p.substring(0, p.lastIndexOf('/')) : '';
    if (!CTX) CTX = '';
}
