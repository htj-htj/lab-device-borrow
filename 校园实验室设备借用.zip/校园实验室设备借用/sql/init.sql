CREATE DATABASE IF NOT EXISTS lab_borrow DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE lab_borrow;

DROP TABLE IF EXISTS borrow_records;
DROP TABLE IF EXISTS devices;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    real_name VARCHAR(50),
    student_no VARCHAR(50),
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL DEFAULT 'student',
    status INT NOT NULL DEFAULT 1,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE devices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_name VARCHAR(100) NOT NULL,
    device_code VARCHAR(50) NOT NULL UNIQUE,
    category VARCHAR(50),
    description TEXT,
    total_quantity INT NOT NULL DEFAULT 1,
    available_quantity INT NOT NULL DEFAULT 1,
    status INT NOT NULL DEFAULT 1,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE borrow_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    device_id INT NOT NULL,
    borrow_quantity INT NOT NULL DEFAULT 1,
    borrow_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expected_return_time DATETIME NOT NULL,
    actual_return_time DATETIME,
    status VARCHAR(20) NOT NULL DEFAULT 'borrowed',
    remark VARCHAR(500),
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (device_id) REFERENCES devices(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (username, password, real_name, student_no, phone, role) VALUES
('admin', '123456', '系统管理员', '20240001', '13800000000', 'admin'),
('student1', '123456', '张三', '20240101', '13900000001', 'student'),
('student2', '123456', '李四', '20240102', '13900000002', 'student'),
('student3', '123456', '王五', '20240103', '13900000003', 'student');

INSERT INTO devices (device_name, device_code, category, description, total_quantity, available_quantity) VALUES
('笔记本电脑', 'LAPTOP-001', '计算机设备', '联想ThinkPad E14，i5-12代，16G内存', 10, 10),
('投影仪', 'PROJ-001', '多媒体设备', '爱普生CB-X05，3300流明', 5, 5),
('示波器', 'OSC-001', '电子仪器', '泰克TBS1104，100MHz带宽', 3, 3),
('万用表', 'MULTI-001', '电子仪器', '福禄克F17B+，数字万用表', 8, 8),
('显微镜', 'MIC-001', '实验仪器', '奥林巴斯CX23，生物显微镜', 6, 6),
('离心机', 'CENT-001', '实验仪器', 'Eppendorf 5810R，冷冻离心机', 2, 2),
('无线鼠标', 'MOUSE-001', '计算机配件', '罗技M220无线鼠标', 20, 20),
('U盘', 'USB-001', '存储设备', '金士顿32GB USB3.0', 15, 15);

INSERT INTO borrow_records (user_id, device_id, borrow_quantity, borrow_time, expected_return_time, status) VALUES
(2, 1, 1, DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_SUB(NOW(), INTERVAL 5 DAY), INTERVAL 7 DAY), 'borrowed'),
(3, 2, 1, DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_ADD(DATE_SUB(NOW(), INTERVAL 3 DAY), INTERVAL 5 DAY), 'borrowed'),
(2, 4, 1, DATE_SUB(NOW(), INTERVAL 10 DAY), DATE_ADD(DATE_SUB(NOW(), INTERVAL 10 DAY), INTERVAL 7 DAY), 'overdue');
